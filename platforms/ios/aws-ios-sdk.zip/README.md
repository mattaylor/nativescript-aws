# Version 2 of the AWS SDK for iOS

## Requirements

* iOS 7 and later
* Xcode 5 and later

## Installation

To start using the AWS SDK for iOS, follow the instructions at [Setup the SDK for iOS](http://docs.aws.amazon.com/mobile/sdkforios/developerguide/setup.html).